create procedure sp_player(IN X int)
BEGIN
	select * from user_info where id = X;
END;

